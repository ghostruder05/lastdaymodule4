package com.cg.appl.entities;

import javax.persistence.Column;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

@Entity(name="trainee")
@Table(name="trainee")


@SequenceGenerator(name="trainee_generator",sequenceName="TRN_SEQ",allocationSize=1,initialValue=1)
public class Trainee {
private int traineeid;
private String traineename;
private String traineedomain;
private String traineelocation;
private String email;
/*public Trainee(int traineeid, String traineename, String traineedomain,
		String traineelocation) {
	super();
	this.traineeid = traineeid;
	this.traineename = traineename;
	this.traineedomain = traineedomain;
	this.traineelocation = traineelocation;
}*/
public Trainee() {
	super();
}

public Trainee(int traineeid, String traineename, String traineedomain,
		String traineelocation, String email) {
	super();
	this.traineeid = traineeid;
	this.traineename = traineename;
	this.traineedomain = traineedomain;
	this.traineelocation = traineelocation;
	this.email = email;
}
@Id
@GeneratedValue(generator="trainee_generator",strategy=GenerationType.SEQUENCE)
public int getTraineeid() {
	return traineeid;
}
public void setTraineeid(int traineeid) {
	this.traineeid = traineeid;
}
@NotNull(message="NAME IS REQUIRED")
@Size(min=1,max=10,message="NAME MUST BE OF SIZE 1 TO 10")
public String getTraineename() {
	return traineename;
}
public void setTraineename(String traineename) {
	this.traineename = traineename;
}
public String getTraineedomain() {
	return traineedomain;
}
public void setTraineedomain(String traineedomain) {
	this.traineedomain = traineedomain;
}
@Column(name="traineeloacation")
public String getTraineelocation() {
	return traineelocation;
}
public void setTraineelocation(String traineelocation) {
	this.traineelocation = traineelocation;
}
@Transient                      //to ignore for interacting with db
@Email(message="invalid email format")
public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

@Override
public String toString() {
	return "Trainee [traineeid=" + traineeid + ", traineename=" + traineename
			+ ", traineedomain=" + traineedomain + ", traineelocation="
			+ traineelocation + ", email=" + email + "]";
}

















}
