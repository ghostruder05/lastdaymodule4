package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;
import com.cg.appl.services.TraineeService;

@Controller
public class TraineeController {
	private TraineeService services;
	private List<String> domainList;
	List<String> locations;

	@PostConstruct
	public void initialize() {
		domainList = new ArrayList<>();
		domainList.add("java");
		domainList.add("dotnet");
		domainList.add("database");
		domainList.add("analytics");

		locations = new ArrayList<>();
		locations.add("pune");
		locations.add("mumbai");
		locations.add("hyd");
		locations.add("goa");
		locations.add("mp");
	}

	@Resource(name = "TraineeService")
	public void setServices(TraineeService services) {
		this.services = services;
	}

	@RequestMapping("authenticate")
	public ModelAndView authenticate(@RequestParam String username,
			@RequestParam String password) {
		System.out.println("in handlecontoller2");
		System.out.println("username");
		System.out.println("password");
		ModelAndView model = new ModelAndView();
		if (username.equals("a") && (password.equals("a"))) {
			model.setViewName("pickoperation");
			model.addObject("username", username);
		} else {
			model.addObject("message", "login unsuccessfel...login again");
			model.setViewName("login");
		}

		return model;

	}

	@RequestMapping("/enter.do")
	public ModelAndView entertraineeno() {
		System.out.println("in handlecontoller1");
		ModelAndView model = new ModelAndView("accept");
		return model;

	}

	@RequestMapping("getdetail")
	public ModelAndView getTraineeDetails(
			@RequestParam("traineeno") int traineeno) {
		System.out.println("in handlecontoller2");
		System.out.println(traineeno);
		// System.out.println("password");
		ModelAndView model = null;
		/*
		 * if(username.equals("a")&&(password.equals("a"))){
		 * model.setViewName("success"); model.addObject("username",username);
		 * }else{ model.addObject("message",
		 * "login unsuccessfel...login again"); model.setViewName("login"); }
		 */

		try {
			Trainee trn = services.getTraineeDetails(traineeno);
			model = new ModelAndView("traineedetails");
			// model.addObject(trn);

			// model.addObject("message", "your traineeno is");
			model.addObject("message1", trn);

		} catch (TraineeException e) {
			model = new ModelAndView("error");
			e.printStackTrace();
		}

		return model;

	}

	@RequestMapping("/list.do")
	public ModelAndView listtrainee() {
		System.out.println("in handlecontoller2");
		ModelAndView model = null;
		try {
			model = new ModelAndView("list");
			List<Trainee> trns = services.getAllTrainee();

			model.addObject("trainees", trns);
		} catch (TraineeException e) {

			e.printStackTrace();
			model = new ModelAndView("error");
			e.printStackTrace();
		}

		return model;

	}

	@RequestMapping("/add.do")
	public ModelAndView admitnewtrn() {
		System.out.println("in handlecontoller3");
		ModelAndView model = new ModelAndView("insertform");

		model.addObject("domains", domainList);
		model.addObject("locations", locations);
		model.addObject("trn", new Trainee());
		return model;

	}

	@RequestMapping("/submit.do")
	public String submitform(@ModelAttribute @Valid Trainee trn,
			BindingResult result, Model model) {
		System.out.println("in handlecontoller4");

		if (result.hasErrors()) {
			model.addAttribute("domains", domainList);
			model.addAttribute("locations", locations);
			model.addAttribute("trn", new Trainee());

			return "insertform";
		}
		try {
			Trainee trn1 = services.admitNewTrn(trn);

			model.addAttribute("trn", trn1);
			return "successinsert";

		} catch (TraineeException e) {
			return "error";

		}

	}

	@RequestMapping("/delete.do")
	public ModelAndView deleteTraineeDetails() {
		System.out.println("in handlecontoller6");
		ModelAndView model = new ModelAndView("deleteform");
		return model;

	}

	@RequestMapping("getdeletedetail")
	public ModelAndView getTraineeDeleteDetails(
			@RequestParam("traineeno") int traineeno) {
		System.out.println("in handlecontoller7");
		System.out.println(traineeno);

		ModelAndView model = null;
		try {
			Trainee trn = services.deletetrn(traineeno);
			model = new ModelAndView("traineedetails");

			model.addObject("message1", trn);

		} catch (TraineeException e) {
			model = new ModelAndView("error");
			e.printStackTrace();
		}

		return model;

	}

	@RequestMapping("/modify.do")
	public ModelAndView updateTraineeDetails() {
		System.out.println("in handlecontoller6");
		ModelAndView model = new ModelAndView("acceptupdateform");

		return model;
	}

	@RequestMapping("getupdatedetail.do")
	public ModelAndView getUTraineeDetails(
			@RequestParam("traineeno") int traineeno) {
		System.out.println("in handlecontoller2");
		System.out.println(traineeno);

		ModelAndView model = null;

		try {
			Trainee trn = services.getTraineeDetails(traineeno);
			System.out.println(trn);
			model = new ModelAndView("updateform");
			model.addObject("domains", domainList);
			model.addObject("locations", locations);
			model.addObject("trn", new Trainee());
			// model.addObject(trn);

			// model.addObject("message", "your traineeno is");
			model.addObject("message1", trn);

		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errmsg", e.getMessage());
		}

		return model;

	}

	@RequestMapping("/update.do")
	public ModelAndView updateform(@ModelAttribute Trainee trn) {
		System.out.println("in handlecontoller9");
		ModelAndView model = null;
		System.out.println(trn);
		try {

			Trainee trn1 = services.updateTrn(trn);
			System.out.println(trn1);

			// model.setViewName("traineedetails");
			model = new ModelAndView("updatetrainee");
			model.addObject("trn2", trn1);

		} catch (TraineeException e) {
			model = new ModelAndView("error");
			// model.addObject("msg", "required insertion failed" +
			// e.getMessage());
			// e.printStackTrace();
		}
		return model;

	}

}
