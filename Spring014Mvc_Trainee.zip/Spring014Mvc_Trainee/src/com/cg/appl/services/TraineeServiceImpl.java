package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.TraineeDao;
import com.cg.appl.daos.TraineeDaoImpl;
import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

@Service("TraineeService")
public class TraineeServiceImpl implements TraineeService {
	private TraineeDao dao;

	@Resource(name = "TraineeDao")
	public void setTraineeDao(TraineeDao dao) {
		this.dao = dao;
	}

	@Override
	public Trainee getTraineeDetails(int traineeid) throws TraineeException {

		return dao.getTraineeDetails(traineeid);
	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {

		return dao.getAllTrainee();
	}

	@Transactional
	@Override
	public Trainee admitNewTrn(Trainee trn) throws TraineeException {
		// TODO Auto-generated method stub
		return dao.admitNewTrn(trn);
	}
@Transactional
	@Override
	public Trainee deletetrn(int traineeid) throws TraineeException {
	return dao.deletetrn(traineeid);

	}

@Override
public Trainee updateTrn(Trainee trn) throws TraineeException {
	
	return dao.updateTrn(trn);
}

}
