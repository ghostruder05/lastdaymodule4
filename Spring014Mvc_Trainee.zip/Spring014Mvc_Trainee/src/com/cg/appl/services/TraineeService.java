package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

public interface TraineeService {
	Trainee getTraineeDetails(int traineeid)throws  TraineeException;
	List<Trainee> getAllTrainee() throws  TraineeException;
	Trainee admitNewTrn(Trainee trn) throws TraineeException;

Trainee deletetrn(int traineeid) throws TraineeException;
Trainee updateTrn(Trainee trn) throws TraineeException;

}
