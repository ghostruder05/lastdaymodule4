package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exception.TraineeException;

@Repository("TraineeDao")
public class TraineeDaoImpl implements TraineeDao {
	private EntityManagerFactory factory;

	@Resource(name = "entityMFactory")
	public void setFactory(EntityManagerFactory factory) {
		this.factory = factory;
	}

	@Override
	public Trainee getTraineeDetails(int traineeid) throws TraineeException {
		EntityManager manager = factory.createEntityManager();
		Trainee trn = manager.find(Trainee.class, traineeid); // find method
																// gives
		// persistent object and is only called in dao class and this is not
		// given to client side
		if (trn == null) {
			throw new TraineeException("wrong trainee");
		}

		return trn;

	}

	@Override
	public List<Trainee> getAllTrainee() throws TraineeException {
		String qryStr = "select t from trainee t";
		EntityManager manager = factory.createEntityManager();
		Query qry = manager.createQuery(qryStr, Trainee.class);
		return qry.getResultList();
	}

	@Override
	public Trainee admitNewTrn(Trainee trn) throws TraineeException {

		try {
			EntityManager manager = factory.createEntityManager();
			EntityTransaction trans = manager.getTransaction();
			trans.begin();
			manager.persist(trn);
			trans.commit();
		} catch (Exception e) {
			throw new TraineeException("cannot insert", e);
		}

		return trn;
	}

	@Override
	public Trainee deletetrn(int traineeid) throws TraineeException {
		try {
			EntityManager manager = factory.createEntityManager();
			EntityTransaction trans = manager.getTransaction();
			trans.begin();
			// Trainee trn = this.getTraineeDetails(traineeid);
			Trainee trn = manager.find(Trainee.class, traineeid);
			System.out.println(trn);
			manager.remove(trn);
			System.out.println("*****************"); // commit works prior to
														// delete
			trans.commit();
			return trn;
		} catch (RollbackException e) {

			throw new TraineeException("deletion problem", e);

		}

	}

	@Override
	public Trainee updateTrn(Trainee trn) throws TraineeException {
		EntityManager manager = factory.createEntityManager();
		EntityTransaction trans = manager.getTransaction();
		trans.begin();
		int id=trn.getTraineeid();
		Trainee trn1=this.getTraineeDetails(id);
		trn1.setTraineename(trn.getTraineename());
		trn1.setTraineedomain(trn.getTraineedomain());
		trn1.setTraineelocation(trn.getTraineelocation());
		manager.merge(trn1);
		System.out.println("*****************"); // commit works prior to
		// delete
trans.commit();
return trn1;
		
	}

}
