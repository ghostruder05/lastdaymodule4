package com.cg.appl.services;

import java.util.List;

import javax.annotation.Resource;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.daos.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Service("empService")
@Transactional
public class EmpServicesImpl implements EmpServices {
	private EmpDao dao;
	
	@Resource(name="empDao")
	public void setEmpDao(EmpDao dao){
		this.dao=dao;
	}
	
	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		
		return dao.getEmpDetails(empId);
	}

	@Override
	public List<Emp> getAllEmp() throws EmpException {
		
		return dao.getAllEmp();
	}
	
	
	@Override
	public Emp insertEmp(Emp emp) throws EmpException {
		
		return dao.insertEmp(emp);
	}

	@Override
	public Emp updateEmp(Emp empDetails)
			throws EmpException {
		
		return dao.updateEmp(empDetails);
	}

	
	@Override
	public int deleteEmp(int empId) throws EmpException {
		
		return dao.deleteEmp(empId);
	}

}
