package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;

@Controller
public class EmpCrudControllers {
	private EmpServices services;
	
	@Resource(name="empService")
	public void setEmpServices(EmpServices services){
		this.services=services;
	}
	
	@RequestMapping("welcome") //url coming from jsp page
	public ModelAndView getWelcomePage(){
		ModelAndView model = new ModelAndView("welcome"); //url for going to next page
		return model;
	}
	
	@RequestMapping("enterEmpNo") //url coming from jsp page
	public ModelAndView welcome(){
		ModelAndView model = new ModelAndView("getDetails"); //url for going to next page
		return model;
	}
	
	@RequestMapping("getEmpDetails")
	public ModelAndView getTraineeDetails(@RequestParam("empId") int empId){
		System.out.println(empId);
		ModelAndView model=null;
		try {
			Emp emp = services.getEmpDetails(empId);
			model = new ModelAndView("empDetails");
			model.addObject("empDetails",emp);
		} catch (EmpException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("listAllEmp")
	public ModelAndView listAllEmp(){
		
		ModelAndView model = null;
		try {
			model = new ModelAndView("listAllEmp");
			List<Emp> emps = services.getAllEmp();
			model.addObject("emps", emps);
		} catch (EmpException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("entryForm")
	public ModelAndView getEntryForm(){
		ModelAndView model = new ModelAndView("entryForm");
		model.addObject("emp", new Emp());
		
		return model;
	}
	
	@RequestMapping("submitEntryForm")
	public ModelAndView submitEntryForm(@ModelAttribute("emp") @Valid Emp emp, BindingResult result){
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model.setViewName("entryForm");
			model.addObject("emp", emp);			
			return model;
		}
		try {
			Emp empResponse = services.insertEmp(emp);
			
			model.setViewName("successInsert");
			model.addObject("emp", empResponse);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record Insertion Failed: "+e.getMessage() );
		}
		return model;
	}
	
	@RequestMapping("getUpdateForm")
	public ModelAndView updateEmpDetails(@RequestParam("id") int empId){
		System.out.println(empId);
		ModelAndView model=null;
		
		try {
			Emp emp = services.getEmpDetails(empId);
			model = new ModelAndView("updateForm");
			
			model.addObject("empDetails",emp);
		} catch (EmpException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("updateEmpDetails")
	public String updatedTraineeDetails(@ModelAttribute("empDetails") @Valid Emp empDetails,BindingResult result, Model model){
		System.out.println(empDetails);
		if(result.hasErrors()){
			System.out.println(result.getAllErrors());
			model.addAttribute("empDetails", empDetails);
			
			return "updateForm";
		}
		try {
			Emp empResponse = services.updateEmp(empDetails);
			model.addAttribute("empDetails", empResponse);
			return "successUpdate";
			/*List<Emp> emps = services.getAllEmp();
			//System.out.println(trainees);
			
			model.addObject("emps", emps);*/
		} catch (EmpException e) {
			model.addAttribute("errMsg", "Record Updation Failed: "+e.getMessage() );
			return "error";
		}		
	}
	
	@RequestMapping("deleteEmp")
	public ModelAndView deleteEmp(@RequestParam("id") int empId){
		System.out.println(empId);
		ModelAndView model = null;
		try {
			services.deleteEmp(empId);
			model = new ModelAndView("listAllEmp");
			List<Emp> emps = services.getAllEmp();
			model.addObject("emps", emps);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record Deletion Failed: "+e.getMessage() );
		}
		return model;
	}
}
