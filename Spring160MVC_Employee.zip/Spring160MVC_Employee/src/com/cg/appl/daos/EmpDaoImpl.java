package com.cg.appl.daos;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Repository("empDao")
public class EmpDaoImpl implements EmpDao {
	@PersistenceContext
	private EntityManager manager;
	
	
	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		
		Emp emp = manager.find(Emp.class, empId);
		return emp;
	}
	@Override
	public List<Emp> getAllEmp() throws EmpException {
			
		Query qry = manager.createNamedQuery("getAllEmps", Emp.class);		
		return qry.getResultList();
	}
	@Override
	public Emp insertEmp(Emp emp) throws EmpException {
		
		manager.persist(emp);				
		return emp;
	}
	@Override
	public Emp updateEmp(Emp empDetails)
			throws EmpException {
		try {
			
			manager.merge(empDetails);
			
		} catch (Exception e) {
			throw new EmpException("Record not updated",e);
		}
		return empDetails;
	}
	@Override
	public int deleteEmp(int empId) throws EmpException {
		
		Emp emp = manager.find(Emp.class, empId);
		manager.remove(emp);
		
		return empId;
	}

}
