package com.cg.appl.daos;

import java.util.List;



import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

public interface EmpDao {
	Emp getEmpDetails(int empId) throws EmpException;
	List<Emp> getAllEmp() throws EmpException;
	Emp insertEmp(Emp emp) throws EmpException;
	Emp updateEmp(Emp empDetails) throws EmpException;
	int deleteEmp(int empId) throws EmpException;
}
