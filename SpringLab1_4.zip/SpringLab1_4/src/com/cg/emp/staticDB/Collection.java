package com.cg.emp.staticDB;

import java.util.ArrayList;
import java.util.List;

import com.cg.emp.entities.Emp;

public class Collection {
static List<Emp> empList=loadList();
public static List<Emp> loadList(){
	return empList;
}
static {
	if(empList==null){
		empList=new ArrayList<Emp>();
		empList.add(new Emp(101,"Saraswati",17500f));
		empList.add(new Emp(102,"Mohan",37500f));
		empList.add(new Emp(103,"Namrata",27500f));
		empList.add(new Emp(104,"Neha",7500f));
	}
}
}
