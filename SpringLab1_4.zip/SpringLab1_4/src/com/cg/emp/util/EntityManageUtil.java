package com.cg.emp.util;

import org.springframework.stereotype.Component;

@Component("dbUtil")
public class EntityManageUtil {

	public EntityManageUtil(){
		System.out.println("in constructor of EntityManageUtil");
	}
}
