package com.cg.emp.entities;

import java.io.Serializable;
public class Emp implements Serializable {

	private int empNo;
	private String empNm;
	private Float empSal;
	
	public Emp() {
		super();
	}

	public Emp(int empNo, String empNm, Float empSal) {
		super();
		this.empNo = empNo;
		this.empNm = empNm;
		this.empSal = empSal;
	}
	public int getEmpNo() {	//Property Name: empNo
		return empNo;
	}

	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}

	public String getEmpNm() {		//empNm
		return empNm;
	}

	public void setEmpNm(String empNm) {
		this.empNm = empNm;
	}

	public Float getEmpSal() {
		return empSal;
	}

	public void setEmpSal(Float empSal) {		//empSal
		this.empSal = empSal;
	}

	@Override
	public String toString() {
		return "Emp [empNo=" + empNo + ", empNm=" + empNm + ", empSal="
				+ empSal + "]";
	}
	
}
