package com.cg.emp.daos;

import java.util.List;
import org.springframework.stereotype.Repository;

import com.cg.emp.entities.Emp;
import com.cg.emp.exceptions.EmpException;
import com.cg.emp.staticDB.Collection;
@Repository("empDao")

public class EmpDaoImpl implements IEmpDao{
	List<Emp> empList=Collection.loadList();
	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		Emp e=new Emp();
		for(Emp e1:empList){
			if(e1.getEmpNo()==empId){
				return e1;
			}
		}
		return e;
	}
}
