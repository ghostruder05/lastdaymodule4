package com.cg.emp.daos;

import com.cg.emp.entities.Emp;
import com.cg.emp.exceptions.EmpException;

public interface IEmpDao {
	public Emp getEmpDetails(int empId) throws EmpException;
}
