package com.cg.emp.tests;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;

import com.cg.emp.entities.Emp;
import com.cg.emp.exceptions.EmpException;
import com.cg.emp.services.EmpServiceImpl;
import com.cg.emp.services.IEmpService;
import com.cg.emp.util.SpringUtil;

public class TestLayering {

	public static void main(String[] args) {
		
		SpringUtil util=new SpringUtil();
		ApplicationContext ctx=util.getSpringContext();
		IEmpService service=ctx.getBean("empService",IEmpService.class);
		try {
			System.out.println("Enter Emp Id:");
			Scanner sc=new Scanner(System.in);
			int eid=sc.nextInt();
			Emp e=service.getEmpDetails(eid);
			
			if(e.getEmpNo()!=0){
				System.out.println("Employee Details :");
				System.out.println("Employee Id : "+e.getEmpNo());
				System.out.println("Employee Name : "+e.getEmpNm());
				System.out.println("Employee Salary : "+e.getEmpSal());
			} 
			else{
				System.out.println("No Employee Data Available");
			}
		} catch (EmpException e) {
			
			e.printStackTrace();
		}
	}

}
