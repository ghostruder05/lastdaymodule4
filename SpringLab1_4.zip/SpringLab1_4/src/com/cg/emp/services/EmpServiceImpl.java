package com.cg.emp.services;


import org.springframework.stereotype.Service;

import com.cg.emp.daos.EmpDaoImpl;
import com.cg.emp.daos.IEmpDao;
import com.cg.emp.entities.Emp;
import com.cg.emp.exceptions.EmpException;

@Service("empService")
public class EmpServiceImpl implements IEmpService {
private IEmpDao dao;
	
	public void setDao(IEmpDao dao){
		this.dao=dao;
	}
	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		
		return dao.getEmpDetails(empId);
	}

}
