package com.cg.appl.exceptions;

public class TraineeException extends Exception {

	private static final long serialVersionUID = 1L;

	public TraineeException() {
		super();
		
	}

	public TraineeException(String message, Throwable cause,
			boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		
	}

	public TraineeException(String message, Throwable cause) {
		super(message, cause);
		
	}

	public TraineeException(String message) {
		super(message);
		
	}

	public TraineeException(Throwable cause) {
		super(cause);
		
	}
	
}
