package com.cg.appl.services;

import java.util.List;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;

public interface TraineeServices {
	Trainee getTraineeDetails(int traineeId) throws TraineeException;
	List<Trainee> getAllTrainee() throws TraineeException;
	Trainee insertTrainee(Trainee trainee) throws TraineeException;
	Trainee updateTrainee(Trainee traineeDetails) throws TraineeException;
	int deleteTrainee(int traineeId) throws TraineeException;
}
