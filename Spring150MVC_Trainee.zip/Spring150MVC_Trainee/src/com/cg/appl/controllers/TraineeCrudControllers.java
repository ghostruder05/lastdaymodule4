package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeException;
import com.cg.appl.services.TraineeServices;

@Controller
public class TraineeCrudControllers {
	private TraineeServices services;
	private List<String> domainList;
	private List<String> locations;
	
	@PostConstruct
	public void initialize(){
		domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add("DotNet");
		domainList.add("Database");
		domainList.add("Analytics");
		
		locations = new ArrayList<>();
		locations.add("Pune");
		locations.add("Mumbai");
		locations.add("Bengaluru");
		locations.add("Kolkata");
		locations.add("Delhi");
	}
	
	@Resource(name="traineeService")
	public void setTraineeServices(TraineeServices services){
		this.services=services;
	}
	
	@RequestMapping("welcome") //url coming from jsp page
	public ModelAndView getWelcomePage(){
		ModelAndView model = new ModelAndView("welcome"); //url for going to next page
		return model;
	}
	
	@RequestMapping("enterTraineeNo") //url coming from jsp page
	public ModelAndView welcome(){
		ModelAndView model = new ModelAndView("getDetails"); //url for going to next page
		return model;
	}
	
	@RequestMapping("getDetails")
	public ModelAndView getTraineeDetails(@RequestParam("traineeId") int traineeId){
		System.out.println(traineeId);
		ModelAndView model=null;
		try {
			Trainee trainee = services.getTraineeDetails(traineeId);
			model = new ModelAndView("traineeDetails");
			model.addObject("traineeDetails",trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("listAllTrainees")
	public ModelAndView listAllTrainees(){
		
		ModelAndView model = null;
		try {
			model = new ModelAndView("listAllTrainees");
			List<Trainee> trainees = services.getAllTrainee();
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("entryForm")
	public ModelAndView getEntryForm(){
		ModelAndView model = new ModelAndView("entryForm");
		model.addObject("trainee", new Trainee());
		model.addObject("domains", domainList);
		model.addObject("locations", locations);
		return model;
	}
	
	@RequestMapping("submitEntryForm")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Trainee trainee, BindingResult result){
		ModelAndView model = new ModelAndView();
		if(result.hasErrors()){
			model.setViewName("entryForm");
			model.addObject("trainee", new Trainee());
			model.addObject("domains", domainList);
			model.addObject("locations", locations);
			return model;
		}
		try {
			Trainee traineeResponse = services.insertTrainee(trainee);
			
			model.setViewName("successInsert");
			model.addObject("trainee", traineeResponse);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record Insertion Failed: "+e.getMessage() );
		}
		return model;
	}
	
	@RequestMapping("updateTrainee")
	public ModelAndView updateTraineeDetails(@RequestParam("id") int traineeId){
		System.out.println(traineeId);
		ModelAndView model=null;
		
		try {
			Trainee trainee = services.getTraineeDetails(traineeId);
			model = new ModelAndView("updateDetails");
			model.addObject("domains", domainList);
			model.addObject("locations", locations);
			model.addObject("traineeDetails",trainee);
		} catch (TraineeException e) {
			model = new ModelAndView("error");
			model.addObject("errMsg",e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("updateTraineeDetails")
	public ModelAndView updatedTraineeDetails(@ModelAttribute Trainee traineeDetails){
		System.out.println(traineeDetails);
		ModelAndView model = null;
		try {
			Trainee trainee = services.updateTrainee(traineeDetails);
			model = new ModelAndView("listAllTrainees");
			List<Trainee> trainees = services.getAllTrainee();
			//System.out.println(trainees);
			
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record Insertion Failed: "+e.getMessage() );
		}
		return model;
	}
	
	@RequestMapping("deleteTrainee")
	public ModelAndView deleteTrainee(@RequestParam("id") int traineeId){
		System.out.println(traineeId);
		ModelAndView model = null;
		try {
			services.deleteTrainee(traineeId);
			model = new ModelAndView("listAllTrainees");
			List<Trainee> trainees = services.getAllTrainee();
			model.addObject("trainees", trainees);
		} catch (TraineeException e) {
			model.setViewName("error");
			model.addObject("errMsg", "Record Deletion Failed: "+e.getMessage() );
		}
		return model;
	}
}
