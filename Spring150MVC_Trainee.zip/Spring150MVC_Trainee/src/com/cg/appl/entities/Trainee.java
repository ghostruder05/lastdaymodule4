package com.cg.appl.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

@Entity(name="trainee")
@Table(name="TRAINEE")
@SequenceGenerator(name="trn_generate", sequenceName="TRN_SEQ", allocationSize=1, initialValue=1005)
public class Trainee {
	@Id
	@Column(name="TRAINEEID")
	@GeneratedValue(generator="trn_generate", strategy=GenerationType.SEQUENCE)
	private int traineeId;
	
	@Column(name="TRAINEENAME")
	@NotNull(message="Name is required.")
	@Size(min=1, max=15, message="Name must have characters 1 to 15")
	private String traineeName;
	
	@Column(name="TRAINEEDOMAIN")
	private String traineeDomain;
	
	@Column(name="TRAINEELOCATION")
	private String traineeLocation;
	
	@Transient
	@Email(message="Invalid email Format.")
	private String email;
	
	public Trainee() {
		
	}
	
	public int getTraineeId() {
		return traineeId;
	}
	public void setTraineeId(int traineeId) {
		this.traineeId = traineeId;
	}
	public String getTraineeName() {
		return traineeName;
	}
	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}
	public String getTraineeDomain() {
		return traineeDomain;
	}
	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}
	public String getTraineeLocation() {
		return traineeLocation;
	}
	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}
	
	
	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Trainee [traineeId=" + traineeId + ", tarineeName="
				+ traineeName + ", traineeDomain=" + traineeDomain
				+ ", traineeLocation=" + traineeLocation + "]";
	}	
}
